﻿#include "Qint.h"
#include "Qfloat.h"
int main()
{
	//Qint a;
	//Qint y;
	//a.ScanQint();
	//y.ScanQint();
	
	//a.printbit(a.CoverttoTwoComPlement(a.readDec("-12")));
	//cout << "\n";
	//Qint temp = x*y;
	//
	////x.printchar(x.DecToHex());
	////y.ScanQint()
	////temp.printbit(temp.DectoBin());
	//x.printQint();
	////x.Init(a);
	////x.CoverttoTwoComPlement(a);
	////x.DectoBin(a);
	Qfloat x;
	/*string s1 = "54";
	string s2 = "123";
	while (s1.length() < s2.length())
	{
		s1.push_back(0 + '0');
	}
	cout << x.PlusTwoString(s1, s2);*/
	x.ScanQfloat();
	//cout<<x.NumberToString(234234234234);
	x.PrintQfloat();
	

	system("pause");
}